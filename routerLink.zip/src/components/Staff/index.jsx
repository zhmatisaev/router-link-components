import React from 'react'

function Staff() {
    return (
        <div>
            <h1>Сотрудники</h1>
        </div>
    )
}

export default Staff
