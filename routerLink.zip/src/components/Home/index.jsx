// import { Card, Avatar, Spin } from 'antd'
// import React, {useState, useEffect} from 'react'
import React from 'react'
import '../../App.css'
function Home() {
    // const [photos, setPhotos] = useState([])
    // const [loading, setLoading] = useState(false);

    // useEffect(() => {
    //     setLoading(true)
    //     fetch('https://jsonplaceholder.typicode.com/photos?_page=1&_limit=10')
    //         .then(response => response.json())
    //         .then(json => {
    //             setPhotos(json)
    //             setLoading(false)
    // })
    // }, [])
    return <div>
        <h1 >Home</h1>
        {/* <div style={styles}> */}
            {/* {
                loading && <div style={{marginTop: "300px", marginLeft: '200px', width: '100px', height: '100px' }}>
                    <Spin/>
                    loading
                </div>
            } */}
            {/* {photos.map((el, id) => {
                return <Card key={id} style={{ width: 300, display: 'flex', margin: 5 }}>
                    <Avatar size={50} src={el.thumbnailUrl} />
                    <h3>{el.title}</h3>
                </Card> */}
            {/* }, [])} */}
        {/* </div> */}
    </div>
}
// const styles = {
//     display: 'flex',
//     width: '1000px',
//     height: '80vh',
//     justifyContext: 'space-between',
//     flexWrap: 'wrap',
//     overflowY: 'scroll'
// }
export default Home
