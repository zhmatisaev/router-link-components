import  Contacts  from "./components/Contacts";
import  About  from "./components/About";
import  Home  from "./components/Home";
import Staff from "./components/Staff";
export const data = [
  {
    route: "/about",
    exact: true,
    name: "О нас",
    component: () => <About />,
  },
  {
    route: "/contacts",
    name: "Контакты",
    component: () => <Contacts />,
  },
  {
    route: "/",
    exact: true,
    name: "Главная",
    component: () => <Home />,
  },
  {
    route: "/staff",
    exact: true,
    name: "Сотрудники",
    component: () => <Staff />,
  },
];
